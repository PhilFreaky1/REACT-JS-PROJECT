import { useEffect, useState } from "react";

function App() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ name: "", email: "", age: "" });
  const [search, setSearch] = useState("");
  const [welcomeMessage, setWelcomeMessage] = useState("");

  useEffect(() => {
    setWelcomeMessage("Welcome to Campus! Add a student or search your class list.");
  }, []);

  function handleChange(event) {
    const { name, value } = event.target;
    setForm((currentForm) => ({ ...currentForm, [name]: value }));
  }

  function handleSubmit(event) {
    event.preventDefault();
    setStudents((currentStudents) => [
      ...currentStudents,
      { ...form, id: `${Date.now()}-${currentStudents.length}` },
    ]);
    setForm({ name: "", email: "", age: "" });
  }

  const filteredStudents = students.filter((student) =>
    student.name.toLowerCase().includes(search.trim().toLowerCase()),
  );

  return (
    <div className="page">
      <div className="app-shell">
        <nav className="top-nav" aria-label="Main navigation">
          <a className="brand" href="#registration">
            <span className="brand-mark" aria-hidden="true">
              S
            </span>
            <span>Campus</span>
          </a>
          <div className="nav-links">
            <a className="nav-link" href="#registration">
              Student Registration
            </a>
            <a className="nav-link" href="#students">
              Students
            </a>
          </div>
        </nav>

        <main>
          {welcomeMessage && (
            <div className="welcome-message" role="status">
              <span className="welcome-icon" aria-hidden="true">
                ✦
              </span>
              <p>{welcomeMessage}</p>
              <button
                aria-label="Dismiss welcome message"
                className="dismiss-welcome"
                onClick={() => setWelcomeMessage("")}
                type="button"
              >
                ×
              </button>
            </div>
          )}

          <header className="page-header">
            <span className="eyebrow">STUDENT MANAGEMENT</span>
            <h1>Student Registration</h1>
            <p>Register students and keep your class list up to date.</p>
          </header>

          <form
            className="registration-card"
            id="registration"
            onSubmit={handleSubmit}
          >
            <div className="form-heading">
              <span className="form-icon" aria-hidden="true">
                +
              </span>
              <div>
                <h2>Register a student</h2>
                <p>Enter the student&apos;s details below.</p>
              </div>
            </div>
            <div className="field field-name">
              <label htmlFor="student-name">Full name</label>
              <input
                autoComplete="name"
                id="student-name"
                name="name"
                onChange={handleChange}
                placeholder="e.g. Jordan Lee"
                required
                value={form.name}
              />
            </div>
            <div className="field">
              <label htmlFor="student-email">Email address</label>
              <input
                autoComplete="email"
                id="student-email"
                name="email"
                onChange={handleChange}
                placeholder="student@example.com"
                required
                type="email"
                value={form.email}
              />
            </div>
            <div className="field">
              <label htmlFor="student-age">Age</label>
              <input
                id="student-age"
                max="120"
                min="1"
                name="age"
                onChange={handleChange}
                placeholder="e.g. 18"
                required
                type="number"
                value={form.age}
              />
            </div>
            <button type="submit">
              <span aria-hidden="true">+</span>
              Register student
            </button>
          </form>

          <section className="students-section" id="students">
            <div className="students-toolbar">
              <div className="section-heading">
                <div>
                  <span className="eyebrow">YOUR CLASS</span>
                  <h2>Registered students</h2>
                </div>
                <span
                  className="student-count"
                  aria-label={`${students.length} students`}
                >
                  {students.length}
                </span>
              </div>
              <div className="search-field">
                <label className="visually-hidden" htmlFor="student-search">
                  Search students by name
                </label>
                <span aria-hidden="true">⌕</span>
                <input
                  autoComplete="off"
                  id="student-search"
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search by name..."
                  type="search"
                  value={search}
                />
              </div>
            </div>
            {students.length === 0 ? (
              <div className="empty-state">
                <span className="empty-icon" aria-hidden="true">
                  +
                </span>
                <p>No students registered yet</p>
                <span>Complete the form above to add your first student.</span>
              </div>
            ) : filteredStudents.length === 0 ? (
              <div className="empty-state">
                <span className="empty-icon" aria-hidden="true">
                  ⌕
                </span>
                <p>No students found</p>
                <span>Try a different name or clear your search.</span>
              </div>
            ) : (
              <ul className="student-list">
                {filteredStudents.map((student) => (
                  <li className="student-card" key={student.id}>
                    <span className="student-avatar" aria-hidden="true">
                      {student.name.charAt(0).toUpperCase()}
                    </span>
                    <div className="student-info">
                      <h3>{student.name}</h3>
                      <p>{student.email}</p>
                    </div>
                    <span className="age-badge">{student.age} years</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </main>
      </div>
    </div>
  );
}

export default App;
